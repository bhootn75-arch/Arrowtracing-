/* Smart Arrow Tracing – offline SW (no change to app logic) */
const CACHE = 'smart-arrow-tracing-v3';

const ASSETS = [
  './index.html',
  './manifest.json',
  './sw.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-192.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    // Cache one-by-one so one failure does not break install
    for (const url of ASSETS) {
      try {
        await cache.add(url);
      } catch (e) {
        try {
          const res = await fetch(url, { cache: 'reload' });
          if (res && res.ok) await cache.put(url, res);
        } catch (_) {}
      }
    }
    // Also cache the directory URL for navigation
    try {
      const res = await fetch('./', { cache: 'reload' });
      if (res && res.ok) await cache.put('./', res);
    } catch (_) {}
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const req = event.request;
  const url = new URL(req.url);

  // Same-origin only
  if (url.origin !== self.location.origin) return;

  // Navigation: network first, fall back to cached index
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const net = await fetch(req);
        const cache = await caches.open(CACHE);
        cache.put('./index.html', net.clone());
        return net;
      } catch (e) {
        const cache = await caches.open(CACHE);
        return (await cache.match('./index.html'))
          || (await cache.match('./'))
          || Response.error();
      }
    })());
    return;
  }

  // Assets: cache first, then network
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(req);
    if (cached) return cached;
    try {
      const net = await fetch(req);
      if (net && net.ok) cache.put(req, net.clone());
      return net;
    } catch (e) {
      // try relative fallbacks
      const path = url.pathname.split('/').pop();
      if (path) {
        const alt = await cache.match('./' + path);
        if (alt) return alt;
      }
      return (await cache.match('./index.html')) || Response.error();
    }
  })());
});
